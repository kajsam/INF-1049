# Oblig 1 for kam025, INF-1049 September 2021

# This directory contains all files for Oblig 1

# Deloppgave 1.1: 	kam025_a1.ipynb

# Deloppgave 1.2: 	kam025_a2.ipynb

# Deloppgave 1.3: 	kam025_a3

	Task 1: 		task1.py 
			Does not expect input from terminal.
			A string is printed. 
	
	Task 2:		task2.py
			Does not expect input from terminal.
			Strings are printed.

	Task 3:		task3.py
			Expects 1 terminal input argument: real number x (float/int/...)
			python task3.py <x>
			String is printed. 

	Task 4: 		task4.py
			Does not expect input from terminal.
			Strings are printed. 


